// import x from "/sandbox/public/story-img/Lal Jhuti Kakatua 1.jpg.bmp;
var stories = [
  {
    id: 1,
    title: "Insy Winsy Spider",
    image: [
      {
        src: "/story-img/Insy Winsy Spider.bmp"
      }
    ],
    pdf: "/story-pdf/Insy Winsy Spider.pdf"
  },
  {
    id: 2,
    title: "Rain On The Green Grass",
    image: [
      {
        src: "/story-img/Rain On The Green Grass.bmp"
      }
    ],
    pdf: ""
  },
  {
    id: 3,
    title: "Lal Jhuti Kakatua ",
    image: [
      { src: "/story-img/Lal Jhuti Kakatua 1.jpg.bmp" },
      { src: "/story-img/Lal Jhuti Kakatua 2.bmp" },
      { src: "/story-img/Lal Jhuti Kakatua 3.bmp" }
    ],
    pdf: ""
  },
  {
    id: 4,
    title: "The tiger comes to tea",
    image: [
      { src: "/story-img/Tiger pg 1.bmp" },
      { src: "/story-img/Tiger pg 2.bmp" },
      { src: "/story-img/Tiger pg 3.bmp" },
      { src: "/story-img/Tiger pg 4.bmp" },
      { src: "/story-img/Tiger pg 5.bmp" },
      { src: "/story-img/tiger pg 6.bmp" },
      { src: "/story-img/Tiger pg 7.bmp" },
      { src: "/story-img/Tiger pg 8.bmp" },
      { src: "/story-img/tiger pg 9.bmp" }
    ],
    pdf: ""
  }
];
export default stories;
