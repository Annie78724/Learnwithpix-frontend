// import React from "react";
var paraArr = {
  para1:
    "The website is designed for children suffering from Cerebral palsy. In this system, the users are given choice to select any image from the database and analysing the image , the system will try to frame a meaningful sentence.",
  para2:
    "This meaningful sentences can be used to build a story , or rhymes etc. The idea of this communication system is to create a mode of communication between the suffering children and the rest of the society. Through the system they can learn as well as they can express themselves."
};
export default paraArr;
