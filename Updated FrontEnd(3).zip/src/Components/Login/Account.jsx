import axios from "axios";
import React from "react";

function Account()
{
    const jwt = localStorage.getItem("token")
    const claims = atob(jwt.split('.')[1]);
    const userid=JSON.parse(claims)._id;
    console.log(userid);
    axios.get("http://localhost:5000/account",
    {
       
          id:userid
        
    }
    ).then((res)=>{
        console.log(res.data);
    console.log(res.status);
    }).catch((err)=>{
        console.log(err)
    }) 
    return <div className="review-container" style={{textAlign:"left"}}>
    <p><strong>Name:</strong></p>
    <p><strong>Email-Id:</strong></p>
    <p><strong>Age:</strong></p>
    <p><strong>Account Type:</strong></p>
    </div>;
}

export default Account;